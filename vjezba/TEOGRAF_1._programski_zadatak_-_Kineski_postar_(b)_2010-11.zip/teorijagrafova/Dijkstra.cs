﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace teorijagrafova
{
    class Dijkstra : Graph
    {
        List<int> putanja;
        Dictionary<int, int> udaljenosti;
        Dictionary<int, int> prethodnik;
        HashSet<int> Vrhovi;
        int pocetniVrh;
        int krajniVrh;

        public Dijkstra(HashSet<int> Vrhovi, int pocetniVrh, int krajniVrh)
        {
            udaljenosti = new Dictionary<int, int>();
            prethodnik = new Dictionary<int, int>();
            this.pocetniVrh = pocetniVrh;
            this.krajniVrh = krajniVrh;
            this.Vrhovi = Vrhovi;

            pronadjiUdaljenosti();
            rekonstruirajPut();
        }

        private void pronadjiUdaljenosti(){
            foreach (int vrh in Vrhovi)
            {
                udaljenosti[vrh] = int.MaxValue;
                prethodnik[vrh] = int.MinValue; //nedefiniran;
            }

            udaljenosti[pocetniVrh] = 0;
            while (Vrhovi.Count > 0)
            {
                int vrh = Vrhovi.ElementAtOrDefault(0);
                foreach (int trenutniVrh in Vrhovi)
                {
                    if (udaljenosti[trenutniVrh] < udaljenosti[vrh])
                    {
                        vrh = trenutniVrh;
                    }
                }

                if (udaljenosti[vrh] == int.MaxValue)
                {
                    break;
                }
                if (vrh == krajniVrh)
                {
                    break;
                }

                Vrhovi.Remove(vrh);

                foreach (int susjedniVrh in susjedniVrhovi[vrh])
                {
                    int trenutnaUdaljenost = udaljenosti[vrh] + udaljenost(vrh, susjedniVrh);
                    if (trenutnaUdaljenost < udaljenosti[susjedniVrh])
                    {
                        udaljenosti[susjedniVrh] = trenutnaUdaljenost;
                        prethodnik[susjedniVrh] = vrh;
                    }
                }
            }
        }

        private void rekonstruirajPut()
        {
            int prethodni = krajniVrh;
            while (prethodnik[prethodni] != int.MinValue)
            {
                putanja.Insert(0, prethodni);
                prethodni = prethodnik[prethodni];
            }
        }

        public int Udaljenost
        {
            get { return udaljenosti[krajniVrh]; }
        }

        public List<int> Putanja
        {
            get { return putanja; }
        }

    }
}
