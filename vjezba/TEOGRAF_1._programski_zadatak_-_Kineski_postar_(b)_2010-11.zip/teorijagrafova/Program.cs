﻿/* Mihokovic Marko
 * 0036437142 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace teorijagrafova
{
    class Program
    {
        class Graf
        {
            int brVrhova; // broj vrhova grafa
            int[,] matSusjed; // matrica susjedstva
            Dictionary<int, List<int>> susjedniVrhovi; // riječnik susjednih vrhova svakom vrhu
            int[] neparniVrhovi; // vrhovi grafa neparnog stupnja
            List<int> dodaniBrid; /* dodani brid skoro eulerovskom grafu, 
                                    sadrži putanju kroz skoroeulerovski graf*/

            /// <summary>
            /// Konstrukor klase, prima čitač datoteke. 
            /// Parsira datoteku i stvara matricu susjedstva.
            /// </summary>
            /// <param name="graphFile"></param>
            public Graf(StreamReader grafDatoteka)
            {
                this.brVrhova = int.Parse(grafDatoteka.ReadLine());
                matSusjed = new int[brVrhova, brVrhova];
                susjedniVrhovi = new Dictionary<int, List<int>>();
                neparniVrhovi = new int[2];
                neparniVrhovi[0] = neparniVrhovi[1] = -1;
                dodaniBrid = new List<int>();

                String procitaniRed;
                String[] brojevi;

                for (int i = 0; i < brVrhova; i++)
                {
                    procitaniRed = grafDatoteka.ReadLine();
                    if (procitaniRed.Equals("")) /* ako je pročitan prazan red*/
                    {
                        i--;
                        continue;
                    }

                    brojevi = procitaniRed.Split(' ');

                    for (int j = 0; j < brVrhova; j++)
                    {
                        matSusjed[i, j] = int.Parse(brojevi[j]);
                    }
                }

                pronadiSusjede();
            }
            /// <summary>
            /// Obilazi matricu susjedstva i popunjava riječnik susjedstva.
            /// </summary>
            private void pronadiSusjede()
            {
                List<int> susjedi;
                for (int i = 0; i < brVrhova; i++)
                {
                    susjedi = new List<int>();
                    for (int j = 0; j < brVrhova; j++)
                    {
                        if (matSusjed[i, j] != 0)
                        {
                            susjedi.Add(j);
                        }
                    }
                    susjedniVrhovi.Add(i, susjedi);
                }
            }
            /// <summary>
            /// Pronalazi sve vrhove grafa.
            /// </summary>
            /// <returns>Listu svih vrhova</returns>
            private List<int> dohvatiSveVrhove()
            {
                List<int> vrhovi = new List<int>();
                for (int i = 0; i < brVrhova; i++)
                {
                    vrhovi.Add(i);
                }
                return vrhovi;
            }
            /// <summary>
            /// Vraća stupanj vrha gledajući broj susjeda u riječniku susjeda.
            /// </summary>
            /// <param name="vrh">Vrh grafa</param>
            /// <returns>Stupanj vrha</returns>
            private int stupanjVrha(int vrh)
            {
                return susjedniVrhovi[vrh].Count;
            }
            /// <summary>
            /// Provijerava da li je graf eulerovski, tako da svim vrhovima
            /// provijeri stupnjeve. Ako su svi vrhovi parnog stupnja,
            /// graf je eulerovski. Inače je skoroeulerovski, te upisuje u 
            /// polje neparniVrhovi oznake neparnih vrhova
            /// </summary>
            /// <returns></returns>
            public bool Eulerovski()
            {
                bool izlaz = true;

                int brNeparnih = 0;
                for (int i = 0; i < brVrhova; i++)
                {
                    if (stupanjVrha(i) % 2 != 0)
                    {
                        neparniVrhovi[brNeparnih] = i;
                        brNeparnih++;
                    }
                    if (brNeparnih >= 2)
                    {
                        izlaz = false;
                        break;
                    }
                }

                return izlaz;
            }

            /// <summary>
            /// Dohvaća udaljenost dva vrha iz matrice susjedstva.
            /// </summary>
            /// <param name="a">Prvi vrh</param>
            /// <param name="b">drugi vrh</param>
            /// <returns>Udaljenost dva vrha</returns>
            private int udaljenost(int a, int b)
            {
                return matSusjed[a, b];
            }

            /// <summary>
            /// Pronalazi najkraći put između dva vrha. U dodaniBrid zapisuje 
            /// najkraći put između dva vrha (neparna vrha).
            /// </summary>
            /// <param name="pocetniVrh">Prvi vrh</param>
            /// <param name="krajniVrh">Drugi vrh</param>
            /// <returns>Najmanja udaljenost između prvog i drugog vrha</returns>
            private int dijkstra(int pocetniVrh, int krajniVrh)
            {
                /* riječnik udaljenosti između pocetniVrh i svih ostalih vrhova */
                Dictionary<int, int> udaljenostiVrhova = new Dictionary<int, int>();
                /* riječnik prethodnih vrhova u optimalnom putu od pocetniVrh*/
                Dictionary<int, int> prethodnik = new Dictionary<int, int>();
                List<int> Vrhovi = dohvatiSveVrhove();

                foreach (int vrh in Vrhovi)
                {
                    udaljenostiVrhova[vrh] = int.MaxValue; /* inicijalizacija svih vrhova na +beskonačno */
                    prethodnik[vrh] = int.MinValue; //nedefiniran;
                }

                udaljenostiVrhova[pocetniVrh] = 0; /* udaljenost od pocetniVrh do pocetniVrh */
                while (Vrhovi.Count > 0)
                {
                    /* odaberi vrh sa najmanjom udaljenošću */
                    int vrh = Vrhovi.ElementAtOrDefault(0);
                    foreach (int trenutniVrh in Vrhovi)
                    {
                        if (udaljenostiVrhova[trenutniVrh] < udaljenostiVrhova[vrh])
                        {
                            vrh = trenutniVrh;
                        }
                    }

                    if (udaljenostiVrhova[vrh] == int.MaxValue)
                    {
                        break; /* ako je vrh nedohvativ iz pocetniVrh */
                    }
                    if (vrh == krajniVrh) /* ako znamo najkraću udaljenost od pocetniVrh do
                                       * kranjiVrh može se ranije prekinuti pretraga */
                    {
                        break;
                    }

                    Vrhovi.Remove(vrh);

                    /*rekonstruirat put*/
                    foreach (int susjedniVrh in susjedniVrhovi[vrh])
                    {
                        int trenutnaUdaljenost = udaljenostiVrhova[vrh] + udaljenost(vrh, susjedniVrh);
                        if (trenutnaUdaljenost < udaljenostiVrhova[susjedniVrh])
                        {
                            udaljenostiVrhova[susjedniVrh] = trenutnaUdaljenost;
                            prethodnik[susjedniVrh] = vrh;
                        }
                    }
                }

                /* popuni dodaniBrid vrhovima*/
                int prethodni = krajniVrh;
                while (prethodnik[prethodni] != int.MinValue)
                {
                    dodaniBrid.Insert(0, prethodni);
                    prethodni = prethodnik[prethodni];
                }
                /*dodaj pocetniVrh na pocetak*/
                dodaniBrid.Insert(0, pocetniVrh);

                return udaljenostiVrhova[krajniVrh];

            }

            /// <summary>
            /// Provijerava da li je graf eulerovski. Ako je potrebno 
            /// računa najkraći put između neparnih vrhova te računa ukupnu
            /// šetnju kineskog poštara.
            /// </summary>
            /// <returns>Duljinu šetnje kineskog poštara</returns>
            public int DuljinaPuta()
            {
                int duljina = 0;

                /* zbroji trokut matrice susjedstva */
                for (int i = 0; i < brVrhova; i++)
                {
                    for (int j = 0; j <= i; j++)
                    {
                        duljina += matSusjed[i, j];
                    }
                }

                if (!Eulerovski())
                {
                    int duljinaDodanog = dijkstra(neparniVrhovi[1], neparniVrhovi[0]);

                    duljina += duljinaDodanog;

                    /* dodaj u riječnik susjedstva dodatni brid kako bi graf
                     * postao Eulerovski */
                    susjedniVrhovi[neparniVrhovi[0]].Add(neparniVrhovi[1]);
                    susjedniVrhovi[neparniVrhovi[1]].Add(neparniVrhovi[0]);
                }
                return duljina;
            }

            /// <summary>
            /// Provijerava da li je zadani brid most, tako da pobriše upitni
            /// brid i pokušava popisati sve vrhove krenuvši od kranjeg
            /// pa sve dok ne dođe do početnog, gledajući susjedne vrhove.
            /// </summary>
            /// <param name="pocetni">Početni vrh brida</param>
            /// <param name="kranji">Kranji vrh brida</param>
            /// <returns>True ako je brid most, inače vraća false.</returns>
            private bool most(int pocetni, int kranji)
            {
                HashSet<int> posjeceniVrhovi = new HashSet<int>();
                Queue<int> neposjeceniVrhovi = new Queue<int>();

                /* zapamti pozicije vrhova u riječniku susjednih i pobriši brid*/
                int pocetniIndex = susjedniVrhovi[kranji].IndexOf(pocetni);
                int krajnjiIndex = susjedniVrhovi[pocetni].IndexOf(kranji);
                brisiBrid(pocetni, kranji, susjedniVrhovi);
                /* tsavi u red kranji brid*/
                neposjeceniVrhovi.Enqueue(kranji);

                while (neposjeceniVrhovi.Count > 0)
                {
                    /* skini brid iz reda*/
                    int vrh = neposjeceniVrhovi.Dequeue();

                    if (posjeceniVrhovi.Contains(pocetni))
                    {
                        /* rekonstruiraj vrhove*/
                        susjedniVrhovi[pocetni].Insert(krajnjiIndex, kranji);
                        susjedniVrhovi[kranji].Insert(pocetniIndex, pocetni);
                        return false;
                    }

                    /* dodaj u set poječenih*/
                    posjeceniVrhovi.Add(vrh);
                    List<int> susjedi = susjedniVrhovi[vrh];
                    /* "obiđi" susjede*/
                    foreach (int element in susjedi)
                    {
                        if (!posjeceniVrhovi.Contains(element))
                        {
                            /* ako već nije posjećen */
                            neposjeceniVrhovi.Enqueue(element);
                        }
                    }
                }

                /* rekonstruiraj vrhove */
                susjedniVrhovi[pocetni].Insert(krajnjiIndex, kranji);
                susjedniVrhovi[kranji].Insert(pocetniIndex, pocetni);
                return true;
            }

            /// <summary>
            /// Pronalazi eulerovu stazu brišući bridove
            /// </summary>
            /// <returns></returns>
            public List<int> Fleury()
            {
                int vrh = 0;
                List<int> eulerovaStaza = new List<int>();
                eulerovaStaza.Add(vrh); // dodaj 0-ti vrh

                int index = 0; // index susjednog vrha u listi susjednih
                while (true)
                {
                    /* ako je riječnik prazan, svi bridovi su pobrisani*/
                    if (pobrisaniSviBridovi(susjedniVrhovi))
                    {
                        break;
                    }

                    /* dohvati prvi susjedni vrh */
                    int susjedniVrh = susjedniVrhovi[vrh][index];

                    if (!most(vrh, susjedniVrh))
                    {
                        index = 0;

                        /* ako je neparan, zamijeni dodani brid sa putom skoroeulerovskog grafa */
                        if ((vrh == neparniVrhovi[0] && susjedniVrh == neparniVrhovi[1]) ||
                                 (vrh == neparniVrhovi[1] && susjedniVrh == neparniVrhovi[0]))
                        {
                            zamijeniDodaniBrid(eulerovaStaza);
                        }

                        else
                        {
                            eulerovaStaza.Add(susjedniVrh);
                        }

                        brisiBrid(vrh, susjedniVrh, susjedniVrhovi);
                        vrh = susjedniVrh;
                    }

                     /* ako je most probaj neki drugi susjedni vrh */
                    else if (index + 1 < susjedniVrhovi[vrh].Count)
                    {
                        index++;
                    }
                    /* nema izbora, mora se proći mostom */
                    else
                    {
                        index = 0;

                        if ((vrh == neparniVrhovi[0] && susjedniVrh == neparniVrhovi[1]) ||
                                (vrh == neparniVrhovi[1] && susjedniVrh == neparniVrhovi[0]))
                        {
                            zamijeniDodaniBrid(eulerovaStaza);
                        }
                        else
                        {
                            eulerovaStaza.Add(susjedniVrh);
                        }

                        brisiBrid(vrh, susjedniVrh, susjedniVrhovi);
                        vrh = susjedniVrh;
                    }
                }
                return eulerovaStaza;
            }

            /// <summary>
            /// Briše brid brišući vrhove iz riječnika susjednih.
            /// </summary>
            /// <param name="a">Prvi vrh brida</param>
            /// <param name="b">Drugi vrh brida</param>
            /// <param name="susjedni">Riječnik susjendih vrhova</param>
            /// <returns>Uspiješnost brisanja</returns>
            private bool brisiBrid(int a, int b, Dictionary<int, List<int>> susjedni)
            {
                bool pobrisanA;
                bool pobrisanB;
                pobrisanA = susjedni[a].Remove(b);
                pobrisanB = susjedni[b].Remove(a);
                return pobrisanA && pobrisanB;
            }

            /// <summary>
            /// Provijerava da li je riječnik prazan, tj da li je svaki vrh ostao izoliran.
            /// </summary>
            /// <param name="susjedni">Riječnik susjednih vrhova</param>
            /// <returns>True ako su svu vrhovi izolirani</returns>
            private bool pobrisaniSviBridovi(Dictionary<int, List<int>> susjedni)
            {
                bool prazan = true;
                foreach (List<int> element in susjedni.Values)
                {
                    if (element.Count != 0)
                    {
                        prazan = false;
                        return prazan;
                    }
                }

                return prazan;
            }

            /// <summary>
            /// Zamijenjuje dodani brid sa putom kroz skoroeulerovski graf, 
            /// čime se označava dvostruki prolazak kroz neki brid.
            /// </summary>
            /// <param name="eulerovaStaza">Staza u koju se dodaje zamijena</param>
            private void zamijeniDodaniBrid(List<int> eulerovaStaza)
            {
                int zadnjiVrhStaze = eulerovaStaza[eulerovaStaza.Count - 1];
                /* ako je zadnji vrh u stazi isto kao i 
                 * početni vrh u dodanom bridu preskoči ga */
                if (zadnjiVrhStaze == dodaniBrid[0])
                {
                    for (int i = 1; i < dodaniBrid.Count; i++)
                    {
                        eulerovaStaza.Add(dodaniBrid[i]);
                    }
                }
                /* ako je zadnji vrh u stazi jednak zadnjem u dodanom bridu
                 * preskoči zadnji vrh*/
                else if (zadnjiVrhStaze == dodaniBrid[dodaniBrid.Count - 1])
                {
                    for (int i = 0; i < dodaniBrid.Count - 1; i++)
                    {
                        eulerovaStaza.Add(dodaniBrid[i]);
                    }
                }
            }

            /// <summary>
            /// Ispiši eulerovu stazu, tj stazu kineskog poštara. 
            /// </summary>
            public void IspisiEulerovuStazu()
            {
                List<int> staza = Fleury();
                for (int i = 0; i < staza.Count; i++)
                {
                    System.Console.Write(staza[i]);

                    if (i != staza.Count - 1)
                    {
                        System.Console.Write(" -> ");
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            try
            {
                StreamReader read = new StreamReader(args[0]);
                Graf graf = new Graf(read);

                /* ispisi najkraci put kineskog postara */
                System.Console.WriteLine(graf.DuljinaPuta());

                //graf.IspisiEulerovuStazu(); //ispisi stazu kineskog postara
            }
            catch
            {
                Console.WriteLine("Greška prilikom otvaranja datoteke");
                return;
            }
        }
    }
}
