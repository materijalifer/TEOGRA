﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace teorijagrafova
{
    class Vrh
    {
        Dictionary<Vrh, int> susjedniVrhovi;
        int stupanj;


        public Vrh(int indexVrha)
        {
            Dictionary<Vrh, int> susjedniVrhovi = new Dictionary<Vrh, int>();
        }
    }
}
