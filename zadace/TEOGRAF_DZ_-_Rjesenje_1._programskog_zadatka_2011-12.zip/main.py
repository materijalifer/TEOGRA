#!/usr/bin/env python2
# ~*~ coding: utf-8 ~*~
#
# Rješenje programskog zadatka predmeta Teorija grafova.
#
# Siniša Biđin, 0036433736

from sys import argv


# Dohvaća matricu, računa najkraće puteve između svih vrhova te ispisuje
# duljinu najduljeg takvog puta.
def main():
  matrica = dohvati_matricu(argv[1])
  putevi = sorted(najkraci_putevi(matrica))
  print putevi[-1]


# Učitava i vraća matricu na temelju puta do datoteke.
def dohvati_matricu(datoteka):
  linije = open(datoteka, 'r').readlines()[2:]
  matrica = map(lambda line: map(int, line.split()), linije)
  return matrica


# Računa i vraća najkraće puteve između svih vrhova grafa.
def najkraci_putevi(matrica):
  vrhova = len(matrica)
  putevi = []

  for i in range(0, vrhova):
    for j in range(i, vrhova):
      put = najkraci_put(i, j, matrica)
      putevi.append(put)

  return putevi


# Vraća se vrhova povezanih s i-tim vrhom u grafu.
def susjedi(i, matrica):
  s = set()
  for vrh, udaljenost in zip(range(0, len(matrica)), matrica[i]):
    if udaljenost != 0: s.add(vrh)
  return s


# Računa i vraća najkraći put između dva vrha u grafu.
def najkraci_put(i, j, matrica):

  # Postavljamo početne udaljenosti između vrhova.
  dist = [None] * len(matrica)
  dist[i] = 0

  # Posebno pazimo na trenutan vrh i neposjećene vrhove.
  current = i
  unvisited = set(range(0, len(matrica)))

  # Ponavljamo Dijkstrin algoritam sve dok ne posjetimo ciljni vrh.
  while True:

    # Nadogradi najkraće udaljenosti do susjeda, ako takvih ima.
    for s in susjedi(current, matrica):
      do_susjeda = dist[current] + matrica[current][s]
      if dist[s] == None or do_susjeda < dist[s]:
        dist[s] = do_susjeda

    # Trenutan čvor je sada službeno posjećen.
    unvisited.remove(current)

    # Ako smo posjetili ciljni čvor, gotovi smo.
    if j not in unvisited:
      break

    # Idući trenutni čvor postaje onaj s najmanjom udaljenošću.
    kandidati = [(dist[v], v) for v in unvisited if dist[v] != None]
    udaljenost, current = sorted(kandidati)[0]

  return dist[j]


if __name__ == "__main__":
  main()
