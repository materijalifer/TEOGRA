// Rješenje programskog zadatka predmeta Teorija grafova.
//
// Siniša Biđin, 0036433736

#include <stdio.h>
#include <string.h>
#include <malloc.h>


// Stvara dvodimenzionalnu kvadratnu matricu integera. Potrebno za stvaranje
// početne matrice susjedstva.
void create_matrix(int ***array, int redaka) {
  int i = 0;
  *array = (int**)malloc(sizeof(int*) * redaka);
  for (i = 0; i < redaka; i++) {
    (*array)[i] = (int*)malloc(sizeof(int) * redaka);
  }
}


// Osvježuje zastavice susjeda. Ukoliko je vrhu i vrh j susjed, tada će
// zastavica ns[i][j] biti 1. Inače, 0. Dijkstrin algoritam na taj način
// određuje koje udaljenosti iz matrice smije uzimati u obzir.
void update_neighbours(int i, int **matrix, int num_nodes, int *ns) {
  int j;

  for (j = 0; j < num_nodes; j++) {
    ns[j] = matrix[i][j] != 0;
  }
}


// Dijkstrin algoritam.
int shortest_path(int i, int j, int **matrix, int num_nodes) {

  // Bilježimo trenutne najmanje udaljenosti između startnog i ostalih vrhova.
  int dist[num_nodes];

  // Koje smo vrhove već posjetili? Za njih je visited[j] == 1.
  int visited[num_nodes];

  // Sadrži 1 na poziciji svakog vrha koji je trenutnom susjed.
  int neighbours[num_nodes];

  int current = i; // Početni trenutni vrh je startni i.
  int dist_to_neighbour, next_current, k;

  // Postavimo sva polja na početne vrijednosti. Ukoliko je udaljenost do
  // vrha trenutno neodređena, bilježimo -1 i u ostatku koda se prema tome
  // odnosimo kao prema beskonačno velikoj udaljenosti.
  for (k = 0; k < num_nodes; k++) {
    dist[k]       = -1;
    visited[k]    = 0;
    neighbours[k] = 0;
  }

  dist[current] = 0; // Udaljenost od početnog do početnog vrha je nula.

  // Ponavljamo korake Dijkstrinog algoritma sve dok ne otkrijemo udaljenost
  // do traženog ciljnog vrha j.
  while (!visited[j]) {

    // Dohvaćamo informacije o susjedima trenutnog vrha.
    update_neighbours(current, matrix, num_nodes, neighbours);

    // Umanjujemo udaljenosti do vrhova, ukoliko je to moguće.
    for (k = 0; k < num_nodes; k++) {

      if (neighbours[k] == 0) continue; // Preskoči vrhove koji nisu susjedi.

      dist_to_neighbour = dist[current] + matrix[current][k];
      if (dist[k] == -1 || dist_to_neighbour < dist[k]) {
        dist[k] = dist_to_neighbour;
      }
    }

    visited[current] = 1;

    // Moramo odrediti idući trenutni vrh putem kojeg ćemo nastaviti
    // pretraživati graf. Za početak, neka to bude prvi dostupni vrh koji nije
    // ni beskonačno udaljen ni već posjećen.
    for (k = 0; k < num_nodes; k++) {
      if (dist[k] != -1 && !visited[k]) {
        next_current = k;
        break;
      }
    }

    // Ukoliko postoji bolji kandidat za idući trenutni vrh, odabiremo ga.
    // Takav vrh mora biti manje udaljen od početnog nego prethodno odabrani
    // kandidat.
    for (k = 0; k < num_nodes; k++) {
      if (dist[k] != -1 && !visited[k] && dist[k] < dist[next_current]) {
        next_current = k;
      }
    }

    // Novi vrh postaje trenutan i ponavljamo korake algoritma.
    current = next_current;
  }

  return dist[j];
}


// Računa najkraće puteve između svake dvije kombinacije vrhova grafa, a
// zatim vraća najdulji takav put.
int longest_shortest_path(int **matrix, int num_nodes) {
  int longest = -1, i, j, len;

  for (i = 0; i < num_nodes; i++) {
    for (j = i; j < num_nodes; j++) {
      len = shortest_path(i, j, matrix, num_nodes);
      if (len > longest) longest = len;
    }
  }

  return longest;
}


// Otvara traženu datoteku i učitava matricu susjedstva.
// Nalazi najdulji najkraći put između dva vrha u grafu i ispisuje ga.
int main(int argc, char **argv) {
  FILE *f = fopen(argv[1], "r");
  int num_nodes = 0, i = 0, j = 0;
  int **matrix = NULL;

  fscanf(f, "%d\n\n", &num_nodes);

  create_matrix(&matrix, num_nodes);

  for (i = 0; i < num_nodes; i++) {
    for (j = 0; j < num_nodes; j++) {
      fscanf(f, "%d", &matrix[i][j]);
      fgetc(f);
    }
  }

  printf("%d\n", longest_shortest_path(matrix, num_nodes));

  return 0;
}
