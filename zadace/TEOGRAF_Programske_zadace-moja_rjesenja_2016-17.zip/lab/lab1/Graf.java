
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * 0036481839
 * 
 * @author Zvonimir Landeka
 * 
 */
public class Graf {
	private boolean foundPath = false;
	private int[][] matrix;
	private int size = -1;
	private int start;
	private ArrayList<Integer> rjesenje = new ArrayList<>();
	private ArrayList<ArrayList<Integer>> svaRjesenja = new ArrayList<>();

	/**
	 * konstruktor koji pokrece citac matrice
	 * 
	 * @param filename
	 */
	public Graf(String filename) {
		try {
			myReadFile(filename);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Metoda koja ucitava datoteku u matricu "matrix"
	 * 
	 * @param filename
	 * @throws IOException
	 */
	public void myReadFile(String filename) throws IOException {

		BufferedReader buffer = new BufferedReader(new FileReader(filename));
		String line;
		size = Integer.parseInt(buffer.readLine());
		while (true) {
			line = buffer.readLine();
			if (!line.trim().isEmpty()) {
				break;
			}
		}
		// line = buffer.readLine();
		matrix = new int[size][size];
		for (int row = 0; row < size; row++) {
			if (row != 0) {
				line = buffer.readLine();
			}
			String[] vals = line.trim().split(" ");
			for (int col = 0; col < size; col++) {
				matrix[row][col] = Integer.parseInt(vals[col]);
			}
		}
		buffer.close();
	}

	/**
	 * Metoda koja ispisuje matricu
	 */
	@Override
	public String toString() {
		StringBuffer buff = new StringBuffer();

		if (matrix != null) {
			for (int row = 0; row < size; row++) {

				for (int col = 0; col < size; col++) {
					buff.append(matrix[row][col]);
					buff.append(" ");
				}
				if (row < size - 1) {
					buff.append("\n");
				}
			}
		}
		return buff.toString();
	}

	public static void main(String[] args) {
		/**
		 * for (int i = 1; i <= 50; i++) { System.out.print(i + ". "); Graf graf
		 * = new
		 * Graf("C:\\Users\\zvone\\Desktop\\faks\\4.god\\2.semestar\\GRAF\\lab1\\tests\\ggf.in."
		 * + i); // System.out.println(graf.toString());
		 * 
		 * graf.execute(); }
		 **/
		Graf graf = new Graf(args[0]);
		// System.out.println(graf.toString());

		graf.execute();

	}

	/**
	 * Metoda za pokretanje trazenja skoro Hamilt.
	 */
	private void execute() {
		if (size == -1) {
			System.out.println("Greskaaaa");
		}

		ArrayList<Integer> neiskoristeni = new ArrayList<Integer>();

		for (int i = 0; i < size; i++) {
			neiskoristeni.add(i);
		}
		try {
			for (int i = 0; i < size; i++) {
				start = i;
				ArrayList<Integer> putanja = new ArrayList<Integer>();
				ArrayList<Integer> bezPoslanog = new ArrayList<>(neiskoristeni);
				bezPoslanog.remove(i);
				putanja.add(i);
				find(i, bezPoslanog, putanja);
			}
		} catch (Exception e) {

		}

		if (foundPath == false) {
			System.out.print("0");
		} else {
			System.out.print("1");
			// ispisiRjesenje(rjesenje, 1);
			// ispisiSvaRjesenja();
		}

	}

	/**
	 * metoda za ispis svih rjesenja
	 */
	private void ispisiSvaRjesenja() {
		int i = 0;
		for (ArrayList<Integer> rjesenje : svaRjesenja) {
			i++;
			ispisiRjesenje(rjesenje, i);
		}
	}

	/**
	 * Metoda za ispis jednog puta
	 * 
	 * @param rjesenje
	 * @param i
	 */
	private void ispisiRjesenje(ArrayList<Integer> rjesenje, int i) {
		System.out.println();
		System.out.print("Rjesenje " + i + ". ");
		for (Integer broj : rjesenje) {
			System.out.print(broj + " ");
		}
	}

	/**
	 * Rekurzija koja pronalazi put. Ako pronade Hammiltonov ciklus baca
	 * iznimku. Rjesenja se pospremaju u globalne varijable
	 * 
	 * @param me
	 * @param neiskoristeni
	 * @param putanja
	 * @throws Exception
	 */
	private void find(Integer me, ArrayList<Integer> neiskoristeni, ArrayList<Integer> putanja) throws Exception {
		if (neiskoristeni.size() == 0) {
			if (matrix[me][start] == 1) {
				foundPath = false;
				throw new Exception();
			} else {
				rjesenje = putanja;
				svaRjesenja.add(putanja);
				foundPath = true;
			}
		}
		for (Integer neiskoristen : neiskoristeni) {
			if (matrix[me][neiskoristen] == 1) {
				ArrayList<Integer> bezNeiskoristenog = new ArrayList<>(neiskoristeni);
				bezNeiskoristenog.remove(neiskoristen);
				ArrayList<Integer> mojaPutanja = new ArrayList<>(putanja);
				mojaPutanja.add(neiskoristen);
				find(neiskoristen, bezNeiskoristenog, mojaPutanja);
			}
		}
	}

}
