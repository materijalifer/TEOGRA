
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * 
 * 
 * @author mlatonja
 * 
 */
public class Graf {

	private int[][] matrix;
	private int size = -1;
	private int[] boja;

	private boolean hasResult = false;

	/**
	 * konstruktor koji pokrece citac matrice
	 * 
	 * @param filename
	 */
	public Graf(String filename) {
		try {
			myReadFile(filename);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Metoda koja ucitava datoteku u matricu "matrix"
	 * 
	 * @param filename
	 * @throws IOException
	 */
	public void myReadFile(String filename) throws IOException {

		BufferedReader buffer = new BufferedReader(new FileReader(filename));
		String line;
		size = Integer.parseInt(buffer.readLine());
		while (true) {
			line = buffer.readLine();
			if (!line.trim().isEmpty()) {
				break;
			}
		}
		// line = buffer.readLine();
		matrix = new int[size][size];
		for (int row = 0; row < size; row++) {
			if (row != 0) {
				line = buffer.readLine();
			}
			String[] vals = line.trim().split(" ");
			for (int col = 0; col < size; col++) {
				matrix[row][col] = Integer.parseInt(vals[col]);
			}
		}
		buffer.close();
	}

	/**
	 * Metoda koja ispisuje matricu
	 */
	@Override
	public String toString() {
		StringBuffer buff = new StringBuffer();

		if (matrix != null) {
			for (int row = 0; row < size; row++) {

				for (int col = 0; col < size; col++) {
					buff.append(matrix[row][col]);
					buff.append(" ");
				}
				if (row < size - 1) {
					buff.append("\n");
				}
			}
		}
		return buff.toString();
	}

	public static void main(String[] args) {

		// Graf graf = new
		// Graf("C:\\Users\\mlatonja\\Desktop\\faks\\4.god\\2.semestar\\GRAF\\labosi\\lab2\\tests\\ggf.in."
		// + 32);

		// Graf graf = new
		// Graf("C:\\Users\\mlatonja\\Desktop\\faks\\4.god\\2.semestar\\GRAF\\labosi\\lab2\\in.1");
		// System.out.println("Izgled grafa:");
		// System.out.println(graf.toString());
		//
		// graf.execute();

		for (int i = 1; i <= 50; i++) {
			System.out.print(i + ". ");
			Graf graf = new Graf(
					"C:\\Users\\mlatonja\\Desktop\\faks\\4.god\\2.semestar\\GRAF\\labosi\\lab2\\tests\\ggf.in." + i);
			// System.out.println(graf.toString());

			graf.execute();
		}

	}

	/**
	 * Metoda koja pokrece rekurzinu metodu koja trazi rjesenje. Ako se dogodi
	 * exception i on se ulovi onda je rjesenje pronadeno.
	 */
	private void execute() {
		if (size == -1) {
			System.out.println("Greskaaaa");
		}
		boja = new int[size];
		for (int i = 0; i < size; i++) {
			boja[i] = 0;
		}
		try {
			find(0);
		} catch (Exception e) {
		}

		if (hasResult == false) {
			System.out.println("0");
		} else {
			System.out.println("Izlaz:");
			System.out.println("1");

			ispisiRjesenje();

		}
	}

	/**
	 * Metoda za ispis boja rjesenja
	 */
	private void ispisiRjesenje() {
		System.out.println("Rjesenje:");
		for (int i = 0; i < size; i++) {
			System.out.print(boja[i] + " ");
		}

	}

	/**
	 * Rekurzija koja tra�i rje�enje. Pokusava na svaki vrh staviti jednu od
	 * boja, ako uspije staviti na sve vrhove boju onda je nasla rjesenje
	 * 
	 * @param me
	 * @throws Exception
	 */
	private void find(Integer me) throws Exception {
		if (me == size) {
			hasResult = true;
			throw new Exception();
		}
		for (int color = 1; color < 4; color++) {
			if (checkIfCanPaint(me, color)) {
				boja[me] = color;
				find(me + 1);
				boja[me] = 0;
			}
		}
	}

	/**
	 * Metoda koja provjerava jel moze na neki vrh staviti boju. Ako susjedni
	 * vrh ima tu istu boju onda ce vratiti false
	 * 
	 * @param me
	 * @param color
	 * @return
	 */
	private boolean checkIfCanPaint(Integer me, Integer color) {
		for (int i = 0; i < size; i++) {
			if (i == me) {
				continue;
			} else if (matrix[me][i] == 1 && boja[i] == color) {
				return false;
			}
		}
		return true;
	}

}
