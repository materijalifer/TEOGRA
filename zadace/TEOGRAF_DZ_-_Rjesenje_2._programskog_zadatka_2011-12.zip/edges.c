// Rješenje programskog zadatka predmeta Teorija grafova.
//
// Programski zadatak 2: bridno obojivi grafovi.
//
// Siniša Biđin, 0036433736
//
// Ima li ulazni graf kromatski indeks jednak najvećem stupnju grafa?
//
// 1 ako da, 0 inače.

#include <stdio.h>
#include <string.h>
#include <malloc.h>

#define DEBUG 0 // Postavi na 1 za detaljni ispis koraka.


// Stvara matricu. Pohranjuje samo njenu donju lijevu polovicu, bez dijagonale
// za koju se pretpostavlja da je ispunjena nulama.
int **create_matrix(int n) {
  int i, **m = malloc((n-1)*sizeof(int*));

  for (i = 0; i < n - 1; i++)
    m[i] = malloc((i+1)*sizeof(int));

  return m;
}


// Oslobađa memoriju zauzetu matricom.
void free_matrix(int **m, int n) {
  int i;
  for (i = 0; i < n - 1; i++) free(m[i]);
  free(m);
}


// Vraća kopiju matrice.
int **copy_matrix(int **m, int n) {
  int i, j, **copy = create_matrix(n);

  for (i = 0; i < n - 1; i++)
    for (j = 0; j <= i; j++)
      copy[i][j] = m[i][j];

  return copy;
}


// Ispisuje donji lijevi dio matrice.
void print_matrix(int **m, int n) {
  int i, j;

  for (i = 0; i < n - 1; i++) {
    for (j = 0; j <= i; j++) printf("%d ", m[i][j]);
    printf("\n");
  }
}


// Ispisuje cijelu matricu.
void print_full_matrix(int **m, int n) {
  int i, j;

  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) printf("%d ", at(m, i, j));
    printf("\n");
  }
}


// Dokle god nijedan element matrice nije negativan, vrati najveći element
// matrice. Inače, vrati -1.
int max_matrix(int **m, int n) {
  int i, j, c, max = -1;

  for (i = 0; i < n - 1; i++) {
    for (j = 0; j <= i; j++) {
      c = m[i][j];
      if      (c > max) max = c;
      else if (c < 0)   return -1;
    }
  }

  return max;
}


// Vraća najveći stupanj u grafu.
int max_degree(int **m, int n) {
  int i, j, neighs, max = 0;

  for (i = 0; i < n; i++) {
    neighs = 0;

    for (j = 0; j < n; j++)
      if (at(m, i, j) != 0)
        neighs++;

    if (neighs > max)
      max = neighs;
  }

  return max;
}


// Postavi vrijednost polja u matrici, pretpostavljajući da su indeksi
// elemenata (i te j) dani kao da radimo s punom n x n matricom, a ne samo
// njenim donjim lijevim dijelom.
void set(int **m, int i, int j, int val) {
  if      (i == j) return;            // Dijagonala je uvijek 0.
  else if (i > j)  m[i-1][j] = val;   // Sve okej, postavi vrijednost.
  else             set(m, j, i, val); // Matrica je simetrična => swap i j.
}


// Koja se vrijednost nalazi u matrici na polju i x j? Pretpostavlja se da su i
// te j dani kao da radimo s punom n x n matricom, slično kao i u (void set).
int at(int **m, int i, int j) {
  if      (i == j) return 0;           // Dijagonala je uvijek 0.
  else if (i > j)  return m[i-1][j];   // Dohvati željenu vrijednost.
  else             return at(m, j, i); // Simetrično => swap i j.
}


// Postavlja sve elemente različite od 0 na val.  Koristi se samo pri početku
// programa, kako bismo sva polja označili neobojanim tako da im damo
// vrijednost -1. Vrijednost +1 bi se protumačila kao "prva boja", a to želimo
// izbjeći.
void set_matrix(int **m, int n, int val) {
  int i, j;

  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      if (at(m, i, j))
        set(m, i, j, val);
}


// Je li čvor node spojen ijednim bridom boje color?  Ovu funkciju koristimo
// kada želimo odabrati boju kojom ćemo obojati brid koji spaja čvor node.
int color_present(int **m, int n, int color, int node) {
  int j;

  for (j = 0; j < n; j++)
    if (at(m, node, j) == color)
      return 1;

  return 0;
}


// Rekurzivna funkcija koja boji trenutan brid u svaku moguću vrijednost, te za
// svaki takav brid zatim boji idući brid u svaku moguću vrijednost, i tako
// FOREVER AND EVER. Odnosno, FOREVER AND EVER sve do trenutka kada su svi
// bridovi obojani, a broj korištenih boja jednak je najvećem stupnju grafa.
//
// max_col je najveći dopustiv broj boja i jednak je max_degree(m, n).
// ei i ej su indeksi trenutnog brida u donjoj lijevoj polovici matrice.
int color_edges(int **m, int n, int max_col, int ei, int ej) {
  int i, j, c, **copy = NULL;

  // Ako smo prošli kroz sve bridove, vraćamo uspjeh (ili ne).
  if (ei == n - 1) {
    if (DEBUG) printf("\nEdge %d %d tried but was outside scope.\n", ei, ej);
    return max_matrix(m, n) == max_col;
  }

  // Koji ćemo brid posjetiti nakon ovog?
  if (ei == ej) {
    i = ei + 1;
    j = 0;
  } else {
    i = ei;
    j = ej + 1;
  }

  // Ako je trenutni brid obojan ili nepostojeć, tražimo idući.
  if (m[ei][ej] != -1) {
    if (DEBUG) printf("\nEdge %d %d invalid, heading %d %d.\n", ei, ej, i, j);
    return color_edges(m, n, max_col, i, j);
  }

  if (DEBUG) {
    printf("\nEXPANDING EDGE %d %d!\n", ei, ej);
    print_matrix(m, n);
  }

  // Obojimo trenutni brid svim mogućim brojama.
  // Za svaku takvu valjanu boju rekurzivno pozivamo funkciju nad idućim bridom.
  for (c = 1; c <= max_col; c++) {
    if (DEBUG) printf("  Trying color %d; ", c);

    // Nalazi li se ta boja među incidentnim bridovima? Ako da,
    // ubijamo ovu granu i pokušavamo opet s nekom drugom bojom.
    if (color_present(m, n, c, ei + 1) || color_present(m, n, c, ej)) {
      if (DEBUG) printf("ALREADY PRESENT!\n");
      continue;
    } else {
      if (DEBUG) printf("ok.\n");
    }

    m[ei][ej] = c; // Obojimo trenutni brid valjanom bojom.

    if (DEBUG) printf("  Jumping to edge %d %d.\n", i, j);

    // Rekurzivne pozive vršimo nad kopijom izmijenjene matrice.
    copy = copy_matrix(m, n);

    // Ukoliko je poziv uspio obojati sve bridove dovoljno malenim brojem boja,
    // ne moramo dalje tražiti.
    if (color_edges(copy, n, max_col, i, j))
      return 1;

    free_matrix(copy, n);
  }

  // Cijela je ova grana bila jedno veliko razočaranje. I quit. ._.
  return 0;
}


int main(int argc, char *argv[]) {
  int n, **m = NULL; // Broj čvorova i matrica susjedstva.
  int i, j, throwaway;
  FILE *f = fopen(argv[1], "r");

  fscanf(f, "%d\n\n", &n); // Koliko je čvorova u grafu?

  m = create_matrix(n);

  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      // Zanima nas samo donji lijevi kut matrice, pošto znamo unaprijed da je
      // simetrična i da su joj dijagonale popunjene nulama.
      if (i > j) fscanf(f, "%d", &m[i-1][j]); // Nova vrijednost!
      else       fscanf(f, "%d", &throwaway); // Odbaci ponavljajuće.

      fgetc(f); // Razmak ili newline.
    }
  }

  fclose(f);

  set_matrix(m, n, -1); // Svaki je brid na početku bezbojan, vrijednosti -1.

  // Poziv rekurzivne funkcije. Rezultat je 1 ukoliko se bridovi grafa mogu
  // obojati koristeći broj boja jednak najvećem stupnju grafa, inače 0.
  printf("%d\n", color_edges(m, n, max_degree(m, n), 0, 0));

  free_matrix(m, n);

  return 0;
}
