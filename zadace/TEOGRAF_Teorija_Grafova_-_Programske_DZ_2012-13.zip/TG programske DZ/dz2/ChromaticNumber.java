import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ChromaticNumber {

	public static int[][] matrix;
	public static List<Integer> allColors;
	public static int[] colors;

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// u�itavanje matrice susjedstva
		matrix = loadMatrix(args[0]);

		if (matrix == null) {
			System.err.println("Error loading matrix!");
			System.exit(-1);
		}

		boolean colorable;
		// sve dostupne boje
		allColors = new ArrayList<Integer>();
		// zapo�ni s jednom
		int numColors = 1;

		while (true) {
			// dodaj novu boju
			allColors.add(numColors);
			// reinicijaliziraj polje boja
			colors = new int[matrix.length];
			// provjeri obojivost
			colorable = checkColorability(0);
			if (colorable) {
				System.out.println(numColors);
				break;
			}
			// pove�aj broj boja
			numColors++;
		}
	}

	// rekurzivna funkcija
	// provjerava obojivost vrha nodeID te, ukoliko je mogu�e obojati ga, poziva
	// istu funkciju za sljede�i vrh
	private static boolean checkColorability(int nodeID) {

		// svi vrhovi obojani
		if (nodeID >= matrix.length)
			return true;

		List<Integer> availableColors = new ArrayList<Integer>(allColors);

		// izbaci boje obojanih susjeda
		// (dovoljno je provjeriti samo one s indeksom manjim od trenutnog vrha)
		for (int j = 0; j < nodeID; j++) {
			if (matrix[nodeID][j] == 1)
				availableColors.remove((Object) colors[j]);
		}

		// nema preostalih boja za trenutni vrh
		if (availableColors.size() == 0)
			return false;

		// za svaku od preostalih boja, pridodaj istu trenutnom vrhu i pozovi
		// funkciju za sljede�i
		for (int c : availableColors) {
			colors[nodeID] = c;
			boolean colorable = checkColorability(nodeID + 1);
			if (colorable) {
				return true;
			}
		}
		return false;
	}

	// u�itava matricu susjedstva iz datoteke
	private static int[][] loadMatrix(String path) {

		int[][] matrix = null;
		BufferedReader br = null;

		try {
			br = new BufferedReader(new FileReader(path));
			String line = br.readLine();
			int size = Integer.parseInt(line);
			matrix = new int[size][size];
			line = br.readLine();
			int row = 0;
			while (row < size) {
				line = br.readLine();
				String[] split = line.split("\\s+");
				int col = 0;
				for (String s : split) {
					matrix[row][col] = Integer.parseInt(s);
					col++;
				}
				row++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return matrix;
	}

}
