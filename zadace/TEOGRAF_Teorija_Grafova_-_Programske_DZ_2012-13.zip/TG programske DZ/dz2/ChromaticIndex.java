import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChromaticIndex {

	public class Edge {
		public int first;
		public int second;

		public Edge(int first, int second) {
			this.first = first;
			this.second = second;
		}
	}

	public static Map<Integer, List<Integer>> edgeHood = new HashMap<Integer, List<Integer>>();
	public static List<Integer> allColors;
	public static int[] colors;
	public static int maxDeg;

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		int[][] matrix = loadMatrix(args[0]);
		Map<Integer, Edge> mEdges = new HashMap<Integer, Edge>();

		if (matrix == null) {
			System.err.println("Error loading matrix!");
			System.exit(-1);
		}
		// printMatrix(matrix);

		ChromaticIndex ci = new ChromaticIndex();
		mapEdges(matrix, mEdges, ci);
		// printEdges(mEdges);
		mapTheHood(mEdges);
		// printTheHood(mEdges);

		maxDeg = findMaxDeg(matrix);
		// System.out.println("maxDeg = " + maxDeg);

		allColors = new ArrayList<Integer>();
		for (int color = 1; color <= maxDeg; color++) {
			allColors.add(color);
		}
		colors = new int[edgeHood.size()];

		boolean colorable = checkMaxDegColorability(0);
		if (colorable)
			System.out.println("Kromatski broj grafa L(G) = " + maxDeg);
		else
			System.out.println("Kromatski broj grafa L(G) = " + (maxDeg + 1));

		// printColors(mEdges);

	}

	// prints edges, assigned colors and their neighbors
	private static void printColors(Map<Integer, Edge> mEdges) {
		for (int key : edgeHood.keySet()) {
			System.out.print(key + "|(" + mEdges.get(key).first + "," + mEdges.get(key).second + ")-c"
					+ colors[key] + ":");
			for (int neighbor : edgeHood.get(key)) {
				System.out.print("(" + mEdges.get(neighbor).first + "," + mEdges.get(neighbor).second + ")");
			}
			System.out.println();
		}

	}

	// recursively assigns a color to an edge, if available, and calls itself on
	// the next edge
	private static boolean checkMaxDegColorability(int edgeID) {

		if (edgeID >= edgeHood.size())
			return true;

		List<Integer> availableColors = new ArrayList<Integer>(allColors);
		for (int neighbor : edgeHood.get(edgeID)) {
			if (neighbor < edgeID)
				availableColors.remove((Object) colors[neighbor]);
		}

		if (availableColors.size() == 0)
			return false;

		for (int c : availableColors) {
			colors[edgeID] = c;
			boolean colorable = checkMaxDegColorability(edgeID + 1);
			if (colorable) {
				return true;
			}
		}
		return false;
	}

	// prints the edge neighborhood
	private static void printTheHood(Map<Integer, Edge> mEdges) {
		for (int key : edgeHood.keySet()) {
			System.out.print(key + "-(" + mEdges.get(key).first + "," + mEdges.get(key).second + "):");
			for (int neighbor : edgeHood.get(key)) {
				System.out.print("(" + mEdges.get(neighbor).first + "," + mEdges.get(neighbor).second + ")");
			}
			System.out.println();
		}
	}

	// puts the edges into a map, where the key is an edge id, and the value the
	// list of its neighbors' ids
	private static void mapTheHood(Map<Integer, Edge> mEdges) {
		for (int key = 0; key < mEdges.size(); key++) {
			int first = mEdges.get(key).first;
			int second = mEdges.get(key).second;
			for (int chain = key + 1; chain < mEdges.size(); chain++) {
				int oFirst = mEdges.get(chain).first;
				int oSecond = mEdges.get(chain).second;
				if (first == oFirst || first == oSecond || second == oFirst || second == oSecond) {
					if (edgeHood.containsKey(key)) {
						edgeHood.get(key).add(chain);
					} else {
						List<Integer> neighbors = new ArrayList<Integer>();
						neighbors.add(chain);
						edgeHood.put(key, neighbors);
					}
					if (edgeHood.containsKey(chain)) {
						edgeHood.get(chain).add(key);
					} else {
						List<Integer> neighbors = new ArrayList<Integer>();
						neighbors.add(key);
						edgeHood.put(chain, neighbors);
					}
				}
			}
		}
	}

	// finds the max degree of the graph
	private static int findMaxDeg(int[][] matrix) {
		int maxDeg = 0;
		for (int i = 0; i < matrix.length; i++) {
			int deg = 0;
			for (int j = 0; j < matrix.length; j++) {
				if (matrix[i][j] == 1)
					deg++;
			}
			if (deg > maxDeg)
				maxDeg = deg;
		}
		return maxDeg;
	}

	// loads the neighborhood matrix from the file
	private static int[][] loadMatrix(String path) {

		int[][] matrix = null;
		BufferedReader br = null;

		try {
			br = new BufferedReader(new FileReader(path));
			// graph size
			String line = br.readLine();
			int size = Integer.parseInt(line);
			matrix = new int[size][size];
			// empty line
			line = br.readLine();
			int row = 0;
			// neighborhood matrix
			while (row < size) {
				line = br.readLine();
				String[] split = line.split("\\s+");
				int col = 0;
				for (String s : split) {
					matrix[row][col] = Integer.parseInt(s);
					col++;
				}
				row++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return matrix;
	}

	// puts the edges into a map, where the key is a sequential edge id, and the
	// value the edge itself
	private static void mapEdges(int[][] neighMatrix, Map<Integer, Edge> map, ChromaticIndex ci) {
		int key = 0;
		for (int i = 0; i < neighMatrix.length; i++) {
			for (int j = i + 1; j < neighMatrix.length; j++) {
				if (neighMatrix[i][j] == 1)
					map.put(key++, ci.new Edge(i, j));
			}
		}
	}

	// prints the neighborhood matrix
	private static void printMatrix(int[][] matrix) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++)
				System.out.print(matrix[i][j]);
			System.out.println();
		}
	}

	// prints the edges
	private static void printEdges(Map<Integer, Edge> map) {
		for (Edge e : map.values())
			System.out.println("(" + e.first + "," + e.second + ")");
	}

}
