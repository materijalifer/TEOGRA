import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HamiltonianGraph {

	// the node of a search graph, contains information about
	// the path to it
	public class Node {

		private int id;
		private List<Integer> pathTo;

		public Node(int id, List<Integer> pathTo) {
			this.id = id;
			this.pathTo = new ArrayList<Integer>();
			this.pathTo.addAll(pathTo);
			this.pathTo.add(this.id);
		}

		public List<Integer> getPathTo() {
			return this.pathTo;
		}

		public int getId() {
			return this.id;
		}

		public boolean pathContains(int j) {
			for (int i : this.pathTo) {
				if (i == j) {
					return true;
				}
			}
			return false;
		}
	}

	// contains the neighborhood matrix of the graph, performs the BFS search
	public class BFSGraphSearch {

		private int[][] matrix;
		// final Hamiltonian cycle
		private List<Integer> cycle;

		public BFSGraphSearch(int[][] matrix) {
			this.matrix = matrix;
			this.cycle = new ArrayList<Integer>();
		}

		// BFS search
		public int findHamiltonianPath(int length) {
			List<Node> toVisit = new ArrayList<Node>();
			// "root" node 0
			toVisit.add(new Node(0, new ArrayList<Integer>()));
			while (!toVisit.isEmpty()) {
				Node current = toVisit.remove(0);
				if (current.getPathTo().size() == length && matrix[current.getId()][0] == 1) {
					Node last = new Node(0, current.getPathTo());
					this.cycle = last.getPathTo();
					return 1;
				}
				// System.out.println("adding (" + current.getPrevious() + "," +
				// current.getId() + ")");
				// System.out.println("current: " + current.getId());
				// for (int i : current.getFullPath()) {
				// System.out.print(i + " ");
				// }
				// System.out.println();
				for (int j = 0; j < matrix.length; j++) {
					if (matrix[current.getId()][j] == 1 && !current.pathContains(j)) {
						// System.out.println("adding node: " + j);
						toVisit.add(new Node(j, current.getPathTo()));
						// System.out.print("toVisit: ");
						// for (Node n : toVisit) {
						// System.out.print(n.getId() + " ");
						// }
						// System.out.println();
					}
				}
			}
			return 0;
		}

		// prints the Hamiltonian cycle
		public void printCycle() {
			for (int i : this.cycle) {
				System.out.print(i + " ");
			}
			System.out.println();
		}
	}

	/**
	 * @param args
	 *            [0] = input file path
	 */
	public static void main(String[] args) {

		int[][] matrix = loadMatrix(args[0]);
		if (matrix == null) {
			System.err.println("Error loading matrix!");
			System.exit(-1);
		}
		// printMatrix(matrix);

		HamiltonianGraph hg = new HamiltonianGraph();
		BFSGraphSearch g = hg.new BFSGraphSearch(matrix);
		int result = g.findHamiltonianPath(matrix.length);
		System.out.println(result);

		// *** uncomment to print full Hamiltonian cycle ***
		g.printCycle();
	}

	// loads the neighborhood matrix from the file
	private static int[][] loadMatrix(String path) {

		int[][] matrix = null;
		BufferedReader br = null;

		try {
			br = new BufferedReader(new FileReader(path));
			// graph size
			String line = br.readLine();
			int size = Integer.parseInt(line);
			matrix = new int[size][size];
			// empty line
			line = br.readLine();
			int row = 0;
			// neighborhood matrix
			while (row < size) {
				line = br.readLine();
				String[] split = line.split("\\s+");
				int col = 0;
				for (String s : split) {
					matrix[row][col] = Integer.parseInt(s);
					col++;
				}
				row++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return matrix;
	}

	// prints the neighborhood matrix
	private static void printMatrix(int[][] matrix) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++)
				System.out.print(matrix[i][j]);
			System.out.println();
		}
	}

}
