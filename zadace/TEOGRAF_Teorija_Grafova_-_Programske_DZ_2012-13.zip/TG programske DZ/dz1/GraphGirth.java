import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GraphGirth {

	// Klasa Node predstavlja �vor u BFS (breadth first search) stablu. 

	public class Node {

		private int id;
		// Put do BFS �vora.
		private List<Integer> pathTo;

		public Node(int id, List<Integer> pathTo) {
			this.id = id;
			this.pathTo = new ArrayList<Integer>(pathTo);
			this.pathTo.add(this.id);
		}

		public int getId() {
			return this.id;
		}
		
		public List<Integer> getFullPath() {
			return this.pathTo;
		}

		public boolean pathContains(int j) {
			for (int i : this.pathTo) {
				if (i == j)
					return true;
			}
			return false;
		}
	}

	// Sadr�i definiciju grafa i pripadni BFS za pronalazak struka.
	
	public class Graph {

		private int[][] matrix;
		private List<Integer> path;

		public Graph(int[][] matrix) {
			this.matrix = matrix;
			this.path = new ArrayList<Integer>();
		}

		// Vra�a kona�ni rezultat - ciklus struka.

		public List<Integer> getPath() {
			return this.path;
		}

		// Provodi BFS na definiranom grafu.
		
		public int findGirth(int i) {
			// Lista �vorova koju treba posjetiti.
			List<Node> toVisit = new ArrayList<Node>();
			toVisit.add(new Node(i, new ArrayList<Integer>()));
			// Dok se ne isprazni lista toVisit, uzima se �vor s po�etka liste.
			while (!toVisit.isEmpty()) {
				Node current = toVisit.remove(0);
				// Ako iz tog �vora postoji brid do po�etnog (i) te ako je put do tog �vora ve�i od 2 (kako put ne bi odmah bio povratak u po�etni),
				// postavlja se path i vra�a duljina.
				if (matrix[current.getId()][i] == 1 && current.getFullPath().size() > 2) {
					path = current.getFullPath();
					path.add(i);
					return path.size() - 1;
				}
				// Ukoliko prethodni uvjeti nisu ispunjeni, za svaki �vor se provjerava mo�e li se do�i u njega iz trenutnog, a da ve� nije bio
				// posje�en. U tom slu�aju ga se postavlja u toVisit listu za obradbu u while petlji.
				for (int j = 0; j < matrix.length; j++) {
					if (matrix[current.getId()][j] == 1 && !current.pathContains(j)) {
						toVisit.add(new Node(j, current.getFullPath()));
					}
				}
			}
			// Ako se ni�ta ne vrati prije nego se toVisit isprazni, vra�a se se beskona�na vrijednost (MAX_VALUE).	
			return Integer.MAX_VALUE;
		}
	}


	// Glavna funkcija koja prima put do definicije grafa. 	

	public static void main(String[] args) {
		
		int[][] matrix = loadMatrix(args[0]);
		if (matrix == null) {
			System.err.println("Error loading matrix");
			System.exit(-1);
		}

		GraphGirth gg = new GraphGirth();
		Graph g = gg.new Graph(matrix);
		int result, best = Integer.MAX_VALUE;
		List<Integer> cycle = null;
		// Poziva se findGirth po�ev�i od svakog vrha grafa.
		for (int i = 0; i < matrix.length; i++) {
			result = g.findGirth(i);
			// Tra�i se najkra�i ciklus.
			if (result < best) {
				best = result;
				cycle = g.getPath();
			}
		}
		// Ispis struka - duljine najkra�eg ciklusa.
		System.out.println(best);
		// Po potrebi ispis �itavog ciklusa.
//		if (cycle != null)
//			printCycle(cycle);
	}

	// U�itavanje matrice susjedstva.

	private static int[][] loadMatrix(String path) {
		int[][] matrix = null;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(path));
			String line;
			// U�itavanje broja redova.
			line = br.readLine();
			int size = Integer.parseInt(line);
			matrix = new int[size][size];
			// U�itavanje praznog reda.
			line = br.readLine();
			int row = 0;
			// U�itavanje matrice.
			while (row < size) {
				line = br.readLine();
				String[] split = line.split("\\s+");
				int col = 0;
				for (String s : split) {
					matrix[row][col] = Integer.parseInt(s);
					col++;
				}
				row++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return matrix;
	}

	// Ispis ciklusa.
	private static void printCycle(List<Integer> list) {
		for (int i : list) {
			System.out.print(i + " ");
		}
		System.out.println();
	}

}
