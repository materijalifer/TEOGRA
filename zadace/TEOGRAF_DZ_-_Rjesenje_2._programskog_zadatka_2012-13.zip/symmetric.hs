#!/usr/bin/env runhaskell

-- Provjerava je li ulazna matrica simetrična s obzirom na dijagonalu ili ne.

import Data.List (transpose)

main :: IO ()
main = interact $ \s ->
  let m = map words . drop 2 $ lines s
  in  show (m == transpose m) ++ "\n"
