/* Programski zadatak 2: pronalazak kromatskog broja bridnog grafa.
   Siniša Biđin, 0036433736 */

#include <malloc.h>

// Stvara kvadratnu matricu `m`, visine i širine `n`.
// Pohranjuje samo donju lijevu polovicu, bez dijagonale.
int **create_matrix(int n) {
  int **m = malloc((n-1)*sizeof(int*));

  for (int i = 0; i < n-1; i++) {
    m[i] = malloc((i+1)*sizeof(int));
  }

  return m;
}

// Oslobađa memoriju zauzetu kvadratnom matricom `m`, širine `n`.
void free_matrix(int ***m, int n) {
  for (int i = 0; i < n-1; i++) {
    free((*m)[i]);
  }

  free(*m);
}

// Postavi element `i x y` matrice `m` na vrijednost `val`.
void set(int ***m, int i, int j, int val) {
  if (i == j) {
    return;
  } else if (i > j) {
    (*m)[i-1][j] = val;
  } else {
    set(m, j, i, val); // Matrica je simetrična => swap i j.
  }
}

// Dohvati vrijednost elementa `i x y` matrice `m`.
int at(int ***m, int i, int j) {
  if (i == j) {
    return 0;
  } else if (i > j) {
    return (*m)[i-1][j];
  } else {
    return at(m, j, i); // Simetrično => swap i j.
  }
}

// Stvara i vraća kopiju matrice `m` duljine `n`.
int **copy_matrix(int ***m, int n) {
  int **copy = create_matrix(n);

  for(int i = 0; i < n; i++) {
    for(int j = 0; j < n; j++) {
      set(&copy, i, j, at(m, i, j));
    }
  }

  return copy;
}

// Pronađi i vrati najveći element matrice.
// Iznimka: ako je ijedan element -1, vrati -1.
int max_matrix(int ***m, int n) {
  int max = -1;

  for(int i = 0; i < n; i++) {
    for(int j = 0; j < n; j++) {
      int c = at(m, i, j);

      if(c > max) {
        max = c;
      } else if(c < 0) {
        return -1;
      }
    }
  }

  return max;
}

// Postavi svaki non-null element matrice na vrijednost `val`.
void set_matrix(int ***m, int n, int val) {
  for(int i = 0; i < n; i++) {
    for(int j = 0; j <= i; j++) {
      if(at(m, i, j)) {
        set(m, i, j, val);
      }
    }
  }
}

// Izračunaj i vrati najveći stupanj grafa.
int max_degree(int ***m, int n) {
  int max = 0;

  for(int i = 0; i < n; i++) {
    int neighs = 0;

    for(int j = 0; j < n; j++) {
      if(at(m, i, j)) {
        neighs++;
      }
    }

    if (neighs > max) {
      max = neighs;
    }
  }

  return max;
}

// Ispisuje čitavu matricu `m`, širine `n`.
void print_matrix(int ***m, int n) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      printf("%d ", at(m, i, j));
    }

    printf("\n");
  }
}

// Učitavamo matricu iz datoteke.
void load_matrix(const char *path, int ***m, int *n) {
  // Stvori matricu odgovarajućih dimenzija.
  FILE *f = fopen(path, "r");
  fscanf(f, "%d\n\n", n);
  *m = create_matrix(*n);

  // Popuni matricu podatcima iz datoteke.
  int _throwaway;
  for (int i = 0; i < *n; i++) {
    for (int j = 0; j < *n; j++) {
      // Zanima nas samo donji lijevi kut matrice, pošto znamo unaprijed da je
      // simetrična i da su joj dijagonale popunjene nulama.
      if (i > j) {
        fscanf(f, "%d", &(*m)[i-1][j]);
      } else {
        fscanf(f, "%d", &_throwaway); // Odbaci ponavljajuće.
      }

      fgetc(f); // Razmak ili newline.
    }
  }

  fclose(f);
}

// Je li čvor `node` spojen s nekim drugim čvorom bridom boje `color`?
int color_present(int ***m, int n, int color, int node) {
  for(int i = 0; i < n; i++) {
    if(at(m, node, i) == color) {
      return 1;
    }
  }

  return 0;
}

// max_col je najveći dopustiv broj boja i jednak je max_degree(m, n).
// ei i ej su indeksi trenutnog brida u donjoj lijevoj polovici matrice.
int recursive_color(int ***m, int n, int max_colors, int ei, int ej) {

  // Ako smo prošli kroz sve bridove, vraćamo uspjeh (ili ne).
  if (ei == n - 1) {
    return max_matrix(m, n) == max_colors;
  }

  // Koji ćemo brid posjetiti nakon ovog?
  int i, j;

  if (ei == ej) {
    i = ei + 1;
    j = 0;
  } else {
    i = ei;
    j = ej + 1;
  }

  // Ako je trenutni brid obojan ili nepostojeć, tražimo idući.
  if ((*m)[ei][ej] != -1) {
    return recursive_color(m, n, max_colors, i, j);
  }

  // Obojimo trenutni brid svim mogućim brojama.
  // Za svaku takvu valjanu boju rekurzivno pozivamo funkciju nad idućim bridom.
  for(int c = 1; c <= max_colors; c++) {

    // Nalazi li se ta boja među incidentnim bridovima? Ako da,
    // ubijamo ovu granu i pokušavamo opet s nekom drugom bojom.
    if(color_present(m, n, c, ei+1) || color_present(m, n, c, ej)) {
      continue;
    }

    // Obojimo trenutni brid valjanom bojom.
    (*m)[ei][ej] = c;

    // Rekurzivne pozive vršimo uvijek nad kopijom izmijenjene matrice.
    int **copy = copy_matrix(m, n);

    // Pokušamo obojati ostale bridove dovoljno malenim brojem boja.
    int result = recursive_color(&copy, n, max_colors, i, j);

    free_matrix(&copy, n);

    // Ako je rekurzivni poziv uspio, našli smo jedan dobar slučaj; prekidamo.
    if(result) {
      return 1;
    }
  }

  // Inače, cijela je ova grana bila jedno veliko razočaranje.
  return 0;
}

// Može li graf biti bridno obojan s `max_colors` brojem boja?
int can_be_colored_with(int ***m, int n, int max_colors) {
  set_matrix(m, n, -1); // Svaki je brid na početku bezbojan (val == -1).
  return recursive_color(m, n, max_colors, 0, 0);
}

int main(int argc, const char **argv) {
  if(argc < 2) {
    printf("Potreban jedan argument: put do matrice susjedstva.\n");
    return 1;
  }

  // Učitaj matricu susjedstva.
  int **m, n;
  load_matrix(argv[1], &m, &n);

  // Graf prvo pokušavamo bridno obojati brojem boja jednakim najvećem stupnju
  // grafa. Ukoliko to nije moguće, kromatski indeks je uvijek za jedan veći.
  int colors = max_degree(&m, n);

  if(!can_be_colored_with(&m, n, colors)) {
    colors++;
  }

  // Kromatski broj bridnog grafa jednak je kromatskom indeksu grafa.
  printf("%d\n", colors);

  free_matrix(&m, n);
  return 0;
}
