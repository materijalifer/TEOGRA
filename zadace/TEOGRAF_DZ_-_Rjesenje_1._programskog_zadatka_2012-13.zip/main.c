/* Programski zadatak 1: pronalazak najkraćeg ciklusa grafa.
   Siniša Biđin, 0036433736 */

#include <malloc.h>
#include <limits.h>

// Stvara kvadratnu matricu `m`, visine i širine `n`.
// Pohranjuje samo donju lijevu polovicu, bez dijagonale.
int **create_matrix(int n) {
  int **m = malloc((n-1)*sizeof(int*));

  for (int i = 0; i < n - 1; i++) {
    m[i] = malloc((i+1)*sizeof(int));
  }

  return m;
}

// Oslobađa memoriju zauzetu kvadratnom matricom `m`, širine `n`.
void free_matrix(int ***m, int n) {
  for (int i = 0; i < n - 1; i++) {
    free((*m)[i]);
  }

  free(*m);
}

// Postavi element `i x y` matrice `m` na virjednost `val`.
void set(int ***m, int i, int j, int val) {
  if (i == j) {
    return;
  } else if (i > j) {
    (*m)[i-1][j] = val;
  } else {
    set(m, j, i, val); // Matrica je simetrična => swap i j.
  }
}

// Dohvati vrijednost elementa `i x y` matrice `m`.
int at(int ***m, int i, int j) {
  if (i == j) {
    return 0;
  } else if (i > j) {
    return (*m)[i-1][j];
  } else {
    return at(m, j, i); // Simetrično => swap i j.
  }
}

// Ispisuje čitavu matricu `m`, širine `n`.
void print_matrix(int ***m, int n) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      printf("%d ", at(m, i, j));
    }

    printf("\n");
  }
}

#ifdef PRINT
// Ispisuje put sagrađen backtrackingom kroz red udaljenosti od početnog vrha.
void print_backtracked_path(int *dist, int n, int ***m, int start, int end) {
  int i = end;

  printf("%d", i);

  while (i != start) {

    printf(" ");

    // For each i's neighbour...
    for (int k = 0; k < n; k++) {
      const int link_dist = at(m, i, k);

      // If the neighbour is link_dist closer to the origin...
      if (link_dist && dist[i] == dist[k] + link_dist) {
        i = k;
        printf("%d", i);
        break;
      }
    }
  }

  printf(" %d\n", end);
}
#endif

// Pronalazi najkraći put između dva vrha i vraća njegovu duljinu.
int shortest_path(int start, int end, int ***m, int n, const int will_print) {

  int dist[n];    // Najmanje udaljenosti od početnog vrha.
  int visited[n]; // Je li vrh već posjećen ili ne?

  // Trenutni i sljedeći vrh.
  int i = start, next = start;

  for (int l = 0; l < n; l++) {
    dist[l] = -1; // Udaljenost od -1 => beskonačno velika udaljenost.
    visited[l] = 0;
  }

  dist[i] = 0; // Udaljenost od početnog do početnog vrha je nula.

  while (!visited[end]) {

    // Računamo udaljenost svakog susjeda od početnog vrha.
    for (int k = 0; k < n; k++) {
      if (at(m, i, k)) {

        // Udaljenosti između vrhova uvijek su 1.
        const int d = dist[i] + 1;

        // Ako je udaljenost manja od stare, koristi je.
        if (dist[k] == -1 || d < dist[k]) {
          dist[k] = d;
        }
      }
    }

    visited[i] = 1;

    // Odabiremo idući vrh: uzimamo prvi neposjećeni s konačnom udaljenošću.
    int all_visited = 1;
    for (int k = 0; k < n; k++) {
      if (dist[k] != -1 && !visited[k]) {
        next = k;
        all_visited = 0;
        break;
      }
    }

    if (all_visited && !visited[end]) {
      return INT_MAX-1; // Ne postoji put između ta dva vrha.
    }

    // Postoji li drugi vrh čija je udaljenost manja? Ako da, on je sljedeći.
    for (int k = 0; k < n; k++) {
      if (dist[k] != -1 && !visited[k] && dist[k] < dist[next]) {
        next = k;
      }
    }

    i = next;
  }

#ifdef PRINT
  if (will_print) {
    print_backtracked_path(dist, n, m, start, end);
  }
#endif

  return dist[end];
}

// Pronađi najkraći ciklus u grafu na temelju matrice susjedstva `n` i broja
// čvorova `n`. Vrati duljinu najkraćeg ciklusa. Na lokacije `start` i `end`
// zapiši indekse susjednih vrhova koji drugim najkraćim putem između sebe
// tvore najkraći ciklus grafa.
int shortest_cycle(int ***m, int n, int *start, int *end) {
  int min = INT_MAX;

  for (int i = 0; i < n-1; i++) {
    for (int j = 0; j <= i; j++) {

      // Za svaki brid grafa...
      if (at(m, i, j)) {

        // Maknemo brid.
        set(m, i, j, 0);

        // Računamo najkraću udaljenost između ta dva čvora grafa.
        // Struk grafa najmanja je (+1) od tako izračunatih udaljenosti.
        int dist = shortest_path(i, j, m, n, 0) + 1;
        if (dist < min) {
          min = dist;
          *start = i;
          *end = j;
        }

        // Vraćamo brid.
        set(m, i, j, 1);
      }
    }
  }

  return min;
}

// Učitavamo matricu iz datoteke.
void load_matrix(const char *path, int ***m, int *n) {
  // Stvori matricu odgovarajućih dimenzija.
  FILE *f = fopen(path, "r");
  fscanf(f, "%d\n\n", n);
  *m = create_matrix(*n);

  // Popuni matricu podatcima iz datoteke.
  int _throwaway;
  for (int i = 0; i < *n; i++) {
    for (int j = 0; j < *n; j++) {
      // Zanima nas samo donji lijevi kut matrice, pošto znamo unaprijed da je
      // simetrična i da su joj dijagonale popunjene nulama.
      if (i > j) {
        fscanf(f, "%d", &(*m)[i-1][j]);
      } else {
        fscanf(f, "%d", &_throwaway); // Odbaci ponavljajuće.
      }

      fgetc(f); // Razmak ili newline.
    }
  }

  fclose(f);
}

#ifdef PRINT
// Ispisujemo najkraći ciklus grafa.
void print_cycle(int ***m, int n, int start, int end) {
  set(m, start, end, 0);
  shortest_path(start, end, m, n, 1);
}
#endif

int main(int argc, const char **argv) {
  // Učitaj matricu.
  int **m, n;
  load_matrix(argv[1], &m, &n);

  // Pronađi najkraći ciklus.
  int start = -1, end = -1;
  int len = shortest_cycle(&m, n, &start, &end);

  // Ispiši duljinu najkraćeg ciklusa.
  if(len == INT_MAX) {
    printf("inf\n");
  } else {
    printf("%d\n", len);
  }

#ifdef PRINT
  // Optionally, ispiši najkraći ciklus.
  print_cycle(&m, n, start, end);
#endif

  free_matrix(&m, n);
  return 0;
}
