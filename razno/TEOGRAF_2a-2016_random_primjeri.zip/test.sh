#!/usr/bin/env bash
INPUTS="*.in"
SOLUTION="$1"
for inp in $INPUTS
do
	out="$(echo $inp| cut -d'.' -f 1).out"
	mineout="$out.mine"
	cmd="$SOLUTION $inp > $mineout"
	eval $cmd
	comp="diff $out $mineout"
	res=`$comp`
	if [ -n "$res" ]; then
    	echo $inp
	fi


done	